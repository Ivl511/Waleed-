document.addEventListener('DOMContentLoaded', function() {
    // Elements
    const loginBtn = document.getElementById('loginBtn');
    const registerBtn = document.getElementById('registerBtn');
    const loginModal = document.getElementById('loginModal');
    const registerModal = document.getElementById('registerModal');
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    const propertyForm = document.getElementById('propertyForm');
    const addPropertySection = document.getElementById('addPropertySection');
    const dashboardSection = document.getElementById('dashboardSection');
    const contactModal = document.getElementById('contactModal');
    const contactBtn = document.getElementById('contactBtn');
    const closeLogin = document.getElementById('closeLogin');
    const closeRegister = document.getElementById('closeRegister');
    const closeContact = document.getElementById('closeContact');
    const contactForm = document.getElementById('contactForm');
    const propertyGrid = document.getElementById('propertyGrid');
    const dashboardContent = document.getElementById('dashboardContent');
    const propertiesContainer = document.getElementById('propertiesContainer');
    const propertyModal = new bootstrap.Modal(document.getElementById('propertyModal'));
    const loginPanel = document.getElementById('loginPanel');
    const adminPanel = document.getElementById('adminPanel');
    const agentProperties = document.getElementById('agentProperties');
    const agentDashboard = document.getElementById('agentDashboard');


    // Modal controls
    loginBtn?.addEventListener('click', () => loginModal.style.display = "block");
    registerBtn?.addEventListener('click', () => registerModal.style.display = "block");
    contactBtn?.addEventListener('click', () => contactModal.style.display = "block");

    // Close modals
    document.querySelectorAll('.close').forEach(closeBtn => {
        closeBtn.addEventListener('click', function() {
            this.closest('.modal').style.display = 'none';
        });
    });

    // Close modal when clicking outside
    window.onclick = function(event) {
        if (event.target.classList.contains('modal')) {
            event.target.style.display = "none";
        }
    }

    // Login form submission - UPDATED
    loginForm?.addEventListener('submit', async function(e) {
        e.preventDefault();
        const formData = new FormData(this);

        try {
            const response = await fetch('/auth/login', {
                method: 'POST',
                body: formData
            });

            const data = await response.json();
            if (data.status === 'success') {
                alert('تم تسجيل الدخول بنجاح!');
                loginPanel.style.display = 'none';
                if (data.user.role === 'admin') {
                    adminPanel.style.display = 'block';
                    loadAdminDashboard();
                } else if (data.user.role === 'agent') {
                    agentDashboard.style.display = 'block';
                    loadAgentDashboard();
                }
                location.reload();
            } else {
                alert(data.message || 'خطأ في تسجيل الدخول');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('حدث خطأ في النظام');
        }
    });

    // Registration form submission - UPDATED
    registerForm?.addEventListener('submit', async function(e) {
        e.preventDefault();
        const formData = new FormData(this);

        try {
            const response = await fetch('/auth/register', {
                method: 'POST',
                body: formData
            });

            const data = await response.json();
            if (data.status === 'success') {
                alert('تم التسجيل بنجاح! يمكنك الآن تسجيل الدخول.');
                registerPanel.style.display = 'none';
                loginPanel.style.display = 'block';
                this.reset();
            } else {
                alert(data.message || 'خطأ في التسجيل');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('حدث خطأ في النظام');
        }
    });

    // Property form submission with file upload
    propertyForm?.addEventListener('submit', async function(e) {
        e.preventDefault();
        const formData = new FormData(this);

        try {
            const response = await fetch('/agent/properties', {
                method: 'POST',
                body: formData
            });

            const data = await response.json();
            if (data.status === 'success') {
                alert('تم إضافة العقار بنجاح!');
                this.reset();
                window.location.reload();
            } else {
                alert(data.message || 'خطأ في إضافة العقار');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('حدث خطأ في النظام');
        }
    });

    // Contact form submission
    contactForm?.addEventListener('submit', async function(e) {
        e.preventDefault();
        const formData = new FormData(contactForm);
        try {
            const response = await fetch('/contact', {
                method: 'POST',
                body: formData
            });
            const data = await response.json();
            if (data.status === 'success') {
                contactModal.style.display = "none";
                contactForm.reset();
                alert('تم إرسال رسالتك بنجاح!');
            } else {
                alert(data.message || 'حدث خطأ أثناء إرسال الرسالة');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('حدث خطأ في النظام');
        }
    });

    function updateUI(user) {
        if (user) {
            if (user.role === 'agent' || user.role === 'admin') {
                addPropertySection.style.display = 'block';
            }
            if (user.role === 'admin') {
                dashboardSection.style.display = 'block';
                loadDashboard();
            }
            loginBtn.style.display = 'none';
            registerBtn.style.display = 'none';
        } else {
            addPropertySection.style.display = 'none';
            dashboardSection.style.display = 'none';
            loginBtn.style.display = 'inline';
            registerBtn.style.display = 'inline';
        }
    }

    async function loadDashboard() {
        try {
            const response = await fetch('/dashboard');
            const data = await response.json();
            if (data.status === 'success') {
                renderDashboard(data.properties);
            }
        } catch (error) {
            console.error('Error loading dashboard:', error);
        }
    }

    function renderDashboard(properties) {
        if (!dashboardContent) return;
        dashboardContent.innerHTML = '';
        properties.forEach(prop => {
            const item = document.createElement('div');
            item.style.borderBottom = '1px solid #ccc';
            item.style.padding = '10px 0';
            item.innerHTML = `
                <strong>${prop.title}</strong> - ${prop.price}
                <br>
                <small>أضيف بواسطة: ${prop.posted_by}</small>
            `;
            dashboardContent.appendChild(item);
        });
    }

    // Show property details when clicking on a property card
    propertiesContainer?.addEventListener('click', async function(e) {
        const propertyCard = e.target.closest('.property-card');
        if (propertyCard) {
            const propertyId = propertyCard.dataset.id;
            try {
                const response = await fetch(`/agent/properties/${propertyId}`);
                const data = await response.json();
                if (data.status === 'success') {
                    const modalContent = document.querySelector('#propertyModal .modal-content');
                    modalContent.innerHTML = data.html;
                    new bootstrap.Modal(document.getElementById('propertyModal')).show();
                }
            } catch (error) {
                console.error('Error:', error);
                alert('حدث خطأ في عرض تفاصيل العقار');
            }
        }
    });


    // تحديث الدالة للتحكم في ظهور حقل رخصة فال
    function toggleLicenseField(role) {
        const licenseDivContainer = document.getElementById('licenseDivContainer');
        const licenseInput = document.getElementById('licenseNumber');

        if (role === 'certified_agent') {
            licenseDivContainer.style.display = 'block';
            licenseInput.required = true;
            licenseInput.pattern = "\\d{10}";  // يجب أن يكون 10 أرقام
            licenseInput.title = "رقم الرخصة يجب أن يتكون من 10 أرقام";
        } else {
            licenseDivContainer.style.display = 'none';
            licenseInput.required = false;
            licenseInput.value = '';
        }
    }

    // تسجيل الدخول
    async function performLogin(username, password) {
        try {
            const response = await fetch('/auth/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ username, password })
            });

            const data = await response.json();
            if (data.status === 'success') {
                loginPanel.style.display = 'none';
                if (data.user.role === 'admin') {
                    adminPanel.style.display = 'block';
                    loadAdminDashboard();
                } else if (data.user.role === 'agent') {
                    loadAgentDashboard(data.user.id);
                }
                updateUI(data.user);
            } else {
                alert(data.message || 'خطأ في تسجيل الدخول');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('حدث خطأ في النظام');
        }
    }

    // تسجيل وسيط جديد
    async function registerAgent(formData) {
        try {
            const response = await fetch('/auth/register', {
                method: 'POST',
                body: formData
            });

            const data = await response.json();
            if (data.status === 'success') {
                alert('تم التسجيل بنجاح! يمكنك الآن تسجيل الدخول.');
                document.getElementById('registerForm').reset();
            } else {
                alert(data.message || 'خطأ في التسجيل');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('حدث خطأ في النظام');
        }
    }

    // إضافة عقار جديد
    async function addProperty(formData) {
        try {
            const response = await fetch('/agent/properties', {
                method: 'POST',
                body: formData
            });

            const data = await response.json();
            if (data.status === 'success') {
                alert('تم إضافة العقار بنجاح!');
                document.getElementById('propertyForm').reset();
                loadAgentDashboard();
            } else {
                alert(data.message || 'خطأ في إضافة العقار');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('حدث خطأ في النظام');
        }
    }

    // تحميل لوحة تحكم الوسيط
    async function loadAgentDashboard(agentId) {
        try {
            const response = await fetch(`/agent/dashboard`);
            const data = await response.json();
            if (data.status === 'success') {
                renderAgentProperties(data.properties);
            }
        } catch (error) {
            console.error('Error:', error);
        }
    }

    // عرض عقارات الوسيط
    function renderAgentProperties(properties) {
        if (!agentProperties) return;
        agentProperties.innerHTML = properties.map(property => `
            <div class="property-item property-card" data-id="${property.id}">
                <img src="${property.mainImage}" alt="${property.title}">
                <h3>${property.title}</h3>
                <p>${property.price} ريال</p>
                <div class="actions">
                    <button onclick="editProperty(${property.id})">تعديل</button>
                    <button onclick="deleteProperty(${property.id})">حذف</button>
                </div>
            </div>
        `).join('');

        // Add event listener for showing property details after rendering
        agentProperties.addEventListener('click', function(e) {
            const propertyCard = e.target.closest('.property-card');
            if (propertyCard) {
                const propertyId = propertyCard.dataset.id;
                showPropertyDetails(propertyId);
            }
        });
    }

    //Placeholder functions -  replace with actual implementations
    function editProperty(propertyId) {
        console.log("Edit property:", propertyId);
        // Add your edit property logic here.
    }
    function deleteProperty(propertyId) {
        console.log("Delete property:", propertyId);
        // Add your delete property logic here.
    }

    // Toggle panels
    window.toggleLoginPanel = function() {
        loginPanel.style.display = loginPanel.style.display === 'none' ? 'block' : 'none';
        registerPanel.style.display = 'none';
    }

    window.toggleRegisterPanel = function() {
        registerPanel.style.display = registerPanel.style.display === 'none' ? 'block' : 'none';
        loginPanel.style.display = 'none';
    }
    //Added showPropertyDetails function from edited code
    async function showPropertyDetails(propertyId) {
        try {
            const response = await fetch(`/agent/properties/${propertyId}`);
            const data = await response.json();
            if (data.status === 'success') {
                const modalContent = document.querySelector('#propertyModal .modal-content');
                modalContent.innerHTML = data.html;
                new bootstrap.Modal(document.getElementById('propertyModal')).show();
            }
        } catch (error) {
            console.error('Error:', error);
            alert('حدث خطأ في عرض تفاصيل العقار');
        }
    }
});