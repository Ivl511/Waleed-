from flask import Flask, render_template
import os
import logging
from sqlalchemy import text
from werkzeug.security import generate_password_hash
from extensions import init_extensions, db, login_manager
from models import User, Property

# Configure logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)

# Configure app
app.config.update(
    SECRET_KEY=os.environ.get("SESSION_SECRET", "dev_key"),
    SQLALCHEMY_DATABASE_URI=os.environ.get("DATABASE_URL"),
    SQLALCHEMY_TRACK_MODIFICATIONS=False,
    PREVIEW_MODE=True  # Enable preview mode to use dummy data
)

#Import os module here
import os

# Configure uploads folder
UPLOAD_FOLDER = os.path.join(app.root_path, 'static/uploads')
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size


# Initialize extensions
try:
    init_extensions(app)
    logger.info("Flask extensions initialized successfully")
except Exception as e:
    logger.error(f"Extension initialization error: {str(e)}")

@login_manager.user_loader
def load_user(user_id):
    try:
        return User.query.get(int(user_id))
    except Exception as e:
        logger.error(f"Error loading user {user_id}: {str(e)}")
        return None

# Import and register blueprints
try:
    from routes.main import main_bp
    from routes.auth import auth_bp
    from routes.agent import agent_bp

    app.register_blueprint(main_bp)
    app.register_blueprint(auth_bp, url_prefix='/auth')
    app.register_blueprint(agent_bp, url_prefix='/agent')
    logger.info("Blueprints registered successfully")
except Exception as e:
    logger.error(f"Blueprint registration error: {str(e)}")

def create_admin_user():
    """Create admin user if not exists"""
    try:
        admin = User.query.filter_by(username='ivl511').first()
        if not admin:
            admin = User(
                username='ivl511',
                phone='966535342404',
                password='Wa@055364',
                role='admin'
            )
            db.session.add(admin)
            db.session.commit()
            logger.info("Admin user created successfully")
    except Exception as e:
        logger.error(f"Error creating admin user: {str(e)}")

# Initialize database
def init_db():
    if not app.config['PREVIEW_MODE']:
        try:
            with app.app_context():
                db.create_all()
                create_admin_user()
                logger.info("Database tables created successfully")
        except Exception as e:
            logger.error(f"Database initialization error: {str(e)}")
            logger.info("Running in preview mode with dummy data")

init_db()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)