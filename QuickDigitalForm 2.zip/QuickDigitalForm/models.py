from datetime import datetime
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from extensions import db

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    phone = db.Column(db.String(20), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    role = db.Column(db.String(20), nullable=False, default='agent')  # 'admin' or 'agent'
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)
    properties = db.relationship('Property', backref='owner', lazy=True)

    def __init__(self, username, phone, password, role='agent'):
        self.username = username
        self.phone = phone
        self.set_password(password)
        self.role = role

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def is_admin(self):
        return self.role == 'admin'

class Property(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    price = db.Column(db.Float, nullable=False)
    description = db.Column(db.Text, nullable=False)
    property_type = db.Column(db.String(50), nullable=False)
    location_city = db.Column(db.String(50), default='الطائف')
    location_district = db.Column(db.String(100), nullable=False)  # مثل الحوية، رحاب
    location_details = db.Column(db.Text)  # تفاصيل إضافية عن الموقع
    rooms = db.Column(db.Integer)
    bathrooms = db.Column(db.Integer)
    has_extension = db.Column(db.Boolean, default=False)  # ملحق
    has_basement = db.Column(db.Boolean, default=False)  # قبو
    area = db.Column(db.Float)
    mainImage = db.Column(db.Text)
    images = db.Column(db.Text)  # JSON string of image URLs
    video_url = db.Column(db.Text)  # رابط الفيديو
    status = db.Column(db.String(20), default='active')
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, onupdate=datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    view_count = db.Column(db.Integer, default=0)

    def increment_views(self):
        self.view_count += 1
        db.session.commit()