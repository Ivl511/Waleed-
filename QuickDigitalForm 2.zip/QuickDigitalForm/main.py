from flask import render_template, request, jsonify, redirect, url_for
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import login_user, logout_user, login_required, current_user
from app import app, db, login_manager
from models import User, Property

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

@app.route('/')
def index():
    try:
        properties = Property.query.order_by(Property.created_at.desc()).all()
        return render_template('index.html', properties=properties)
    except Exception as e:
        app.logger.error(f"Error in index route: {str(e)}")
        return "حدث خطأ في تحميل الصفحة", 500

@app.route('/login', methods=['POST'])
def login():
    username = request.form.get('username')
    password = request.form.get('password')
    user = User.query.filter_by(username=username).first()
    if user and check_password_hash(user.password_hash, password):
        login_user(user)
        return jsonify({
            "status": "success",
            "user": {"id": user.id, "username": user.username, "role": user.role}
        })
    return jsonify({"status": "error", "message": "بيانات الدخول غير صحيحة"}), 401

@app.route('/register', methods=['POST'])
def register():
    username = request.form.get('username')
    password = request.form.get('password')
    role = request.form.get('role', 'user')

    if User.query.filter_by(username=username).first():
        return jsonify({"status": "error", "message": "اسم المستخدم موجود بالفعل"}), 400

    user = User(
        username=username,
        password_hash=generate_password_hash(password),
        role=role
    )
    db.session.add(user)
    db.session.commit()
    return jsonify({"status": "success", "message": "تم التسجيل بنجاح"})

@app.route('/add_property', methods=['POST'])
@login_required
def add_property():
    if current_user.role not in ['agent', 'admin']:
        return jsonify({"status": "error", "message": "غير مصرح لك بإضافة عقارات"}), 403

    property = Property(
        title=request.form.get('title'),
        price=request.form.get('price'),
        description=request.form.get('description'),
        image_url=request.form.get('image_url', "https://via.placeholder.com/300x150"),
        user_id=current_user.id
    )
    db.session.add(property)
    db.session.commit()
    return jsonify({"status": "success", "property": {
        "title": property.title,
        "price": property.price,
        "description": property.description,
        "image": property.image_url
    }})

@app.route('/dashboard')
@login_required
def dashboard():
    if current_user.role != 'admin':
        return jsonify({"status": "error", "message": "غير مصرح لك بالوصول"}), 403

    properties = Property.query.join(User).all()
    return jsonify({
        "status": "success",
        "properties": [{
            "title": p.title,
            "price": p.price,
            "description": p.description,
            "posted_by": p.user.username
        } for p in properties]
    })

@app.route('/contact', methods=['POST'])
def contact():
    name = request.form.get('name')
    message = request.form.get('message')
    # Here you would typically send an email or save to database
    return jsonify({"status": "success", "message": "تم إرسال رسالتك بنجاح"})

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)