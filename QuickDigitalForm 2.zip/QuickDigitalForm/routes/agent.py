from flask import Blueprint, request, jsonify, current_app, render_template_string
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename
import os
import json
from models import Property, User
from extensions import db

agent_bp = Blueprint('agent', __name__)

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'mp4', 'mov'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@agent_bp.route('/properties', methods=['GET'])
@login_required
def get_agent_properties():
    try:
        if current_user.is_admin():
            properties = Property.query.all()
        else:
            properties = Property.query.filter_by(user_id=current_user.id).all()

        return jsonify({
            "status": "success",
            "properties": [
                {
                    "id": p.id,
                    "title": p.title,
                    "price": p.price,
                    "description": p.description,
                    "property_type": p.property_type,
                    "rooms": p.rooms,
                    "bathrooms": p.bathrooms,
                    "area": p.area,
                    "city": p.location_city,
                    "district": p.location_district,
                    "mainImage": p.mainImage,
                    "images": json.loads(p.images) if p.images else [],
                    "video_url": p.video_url,
                    "status": p.status,
                    "owner": {
                        "id": p.owner.id,
                        "username": p.owner.username,
                        "phone": p.owner.phone
                    }
                } for p in properties
            ]
        })
    except Exception as e:
        current_app.logger.error(f"Error fetching properties: {str(e)}")
        return jsonify({
            "status": "error",
            "message": "حدث خطأ في جلب العقارات"
        }), 500

@agent_bp.route('/properties/<int:property_id>')
def get_property_details(property_id):
    try:
        property = Property.query.get_or_404(property_id)
        html = render_template_string(
            open('templates/property_details.html').read(),
            property=property
        )
        return jsonify({
            "status": "success",
            "html": html
        })
    except Exception as e:
        current_app.logger.error(f"Error getting property details: {str(e)}")
        return jsonify({
            "status": "error",
            "message": "حدث خطأ في عرض تفاصيل العقار"
        }), 500


@agent_bp.route('/properties', methods=['POST'])
@login_required
def add_property():
    try:
        # معالجة الصور والفيديو
        main_image = request.files.get('mainImage')
        additional_images = request.files.getlist('images')
        video = request.files.get('video')

        # حفظ الملفات
        main_image_url = None
        if main_image and allowed_file(main_image.filename):
            filename = secure_filename(main_image.filename)
            main_image.save(os.path.join('static/uploads', filename))
            main_image_url = f'/static/uploads/{filename}'

        image_urls = []
        for image in additional_images:
            if image and allowed_file(image.filename):
                filename = secure_filename(image.filename)
                image.save(os.path.join('static/uploads', filename))
                image_urls.append(f'/static/uploads/{filename}')

        video_url = None
        if video and allowed_file(video.filename):
            filename = secure_filename(video.filename)
            video.save(os.path.join('static/uploads', filename))
            video_url = f'/static/uploads/{filename}'

        # إنشاء العقار
        property = Property(
            title=request.form['title'],
            price=float(request.form['price']),
            description=request.form['description'],
            property_type=request.form['property_type'],
            location_city=request.form.get('location_city', 'الطائف'),
            location_district=request.form['location_district'],
            location_details=request.form.get('location_details'),
            rooms=request.form.get('rooms', type=int),
            bathrooms=request.form.get('bathrooms', type=int),
            has_extension=request.form.get('has_extension', type=bool),
            has_basement=request.form.get('has_basement', type=bool),
            area=request.form.get('area', type=float),
            mainImage=main_image_url,
            images=json.dumps(image_urls) if image_urls else None,
            video_url=video_url,
            user_id=current_user.id
        )

        db.session.add(property)
        db.session.commit()

        return jsonify({
            "status": "success",
            "message": "تم إضافة العقار بنجاح",
            "property_id": property.id
        })
    except Exception as e:
        current_app.logger.error(f"Error adding property: {str(e)}")
        db.session.rollback()
        return jsonify({
            "status": "error",
            "message": "حدث خطأ في إضافة العقار"
        }), 500

@agent_bp.route('/properties/<int:property_id>', methods=['PUT'])
@login_required
def update_property(property_id):
    try:
        property = Property.query.get_or_404(property_id)
        if property.user_id != current_user.id and not current_user.is_admin():
            return jsonify({
                "status": "error",
                "message": "غير مصرح لك بتعديل هذا العقار"
            }), 403

        data = request.get_json()
        for field in ['title', 'price', 'description', 'property_type', 'rooms',
                     'bathrooms', 'area', 'location_city', 'location_district', 'mainImage', 'images', 'video_url', 'location_details', 'has_extension', 'has_basement']:
            if field in data:
                setattr(property, field, data[field])

        db.session.commit()
        return jsonify({
            "status": "success",
            "message": "تم تحديث العقار بنجاح"
        })
    except Exception as e:
        current_app.logger.error(f"Error updating property: {str(e)}")
        db.session.rollback()
        return jsonify({
            "status": "error",
            "message": "حدث خطأ في تحديث العقار"
        }), 500

@agent_bp.route('/properties/<int:property_id>', methods=['DELETE'])
@login_required
def delete_property(property_id):
    try:
        property = Property.query.get_or_404(property_id)
        if property.user_id != current_user.id and not current_user.is_admin():
            return jsonify({
                "status": "error",
                "message": "غير مصرح لك بحذف هذا العقار"
            }), 403

        # حذف الملفات المرتبطة
        if property.mainImage:
            try:
                os.remove(os.path.join('static', property.mainImage.lstrip('/')))
            except:
                pass

        if property.images:
            for image_url in json.loads(property.images):
                try:
                    os.remove(os.path.join('static', image_url.lstrip('/')))
                except:
                    pass

        if property.video_url:
            try:
                os.remove(os.path.join('static', property.video_url.lstrip('/')))
            except:
                pass

        db.session.delete(property)
        db.session.commit()

        return jsonify({
            "status": "success",
            "message": "تم حذف العقار بنجاح"
        })
    except Exception as e:
        current_app.logger.error(f"Error deleting property: {str(e)}")
        db.session.rollback()
        return jsonify({
            "status": "error",
            "message": "حدث خطأ في حذف العقار"
        }), 500

@agent_bp.route('/dashboard')
@login_required
def agent_dashboard():
    try:
        if current_user.is_admin():
            properties = Property.query.all()
            users = User.query.filter_by(role='agent').all()
            return jsonify({
                "status": "success",
                "properties": [property_to_dict(p) for p in properties],
                "users": [
                    {
                        "id": u.id,
                        "username": u.username,
                        "phone": u.phone,
                        "properties_count": len(u.properties)
                    } for u in users
                ]
            })
        else:
            properties = Property.query.filter_by(user_id=current_user.id).all()
            return jsonify({
                "status": "success",
                "properties": [property_to_dict(p) for p in properties]
            })
    except Exception as e:
        current_app.logger.error(f"Error in dashboard: {str(e)}")
        return jsonify({
            "status": "error",
            "message": "حدث خطأ في لوحة التحكم"
        }), 500

def property_to_dict(property):
    return {
        "id": property.id,
        "title": property.title,
        "price": property.price,
        "description": property.description,
        "property_type": property.property_type,
        "location_city": property.location_city,
        "location_district": property.location_district,
        "location_details": property.location_details,
        "rooms": property.rooms,
        "bathrooms": property.bathrooms,
        "area": property.area,
        "mainImage": property.mainImage,
        "images": json.loads(property.images) if property.images else [],
        "video_url": property.video_url,
        "has_extension": property.has_extension,
        "has_basement": property.has_basement,
        "status": property.status,
        "owner": {
            "id": property.owner.id,
            "username": property.owner.username,
            "phone": property.owner.phone
        }
    }