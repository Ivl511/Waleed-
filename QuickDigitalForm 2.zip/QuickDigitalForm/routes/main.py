from flask import Blueprint, render_template, current_app
from flask_login import login_required, current_user
from models import Property, User
from datetime import datetime

main_bp = Blueprint('main', __name__)

def get_dummy_properties():
    """Return dummy property data for design preview"""
    # قائمة بصور عقارية حقيقية
    real_estate_images = [
        'https://images.unsplash.com/photo-1580587771525-78b9dba3b914',
        'https://images.unsplash.com/photo-1613977257363-707ba9348227',
        'https://images.unsplash.com/photo-1564013799919-ab600027ffc6',
        'https://images.unsplash.com/photo-1576941089067-2de3c901e126',
        'https://images.unsplash.com/photo-1598228723793-52759bba239c',
        'https://images.unsplash.com/photo-1582407947304-fd86f028f716',
        'https://images.unsplash.com/photo-1600585154340-be6161a56a0c',
        'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9',
        'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c'
    ]

    # تعريف الأقسام العقارية الستة
    property_types = ['عمائر', 'شقق', 'فلل', 'استراحات', 'أراضي', 'أدوار مستقلة']
    districts = ['حي الشفا', 'حي السلامة', 'حي الياسمين', 'وسط المدينة', 'حي الحمراء', 'حي النزهة', 'حي الروضة']
    statuses = ['active', 'reserved', 'sold']

    properties = []
    properties_per_type = 8  # لضمان توزيع متساوي تقريباً (8 × 6 = 48 + 1 = 49)

    for type_index, property_type in enumerate(property_types):
        for i in range(properties_per_type):
            property_id = type_index * properties_per_type + i + 1
            if property_id > 49:  # نتوقف عند 49 عقار
                break

            properties.append({
                'id': property_id,
                'title': f'{property_type} فاخر للبيع في {districts[i % len(districts)]}',
                'price': (property_id * 500000) + 1000000,
                'description': f'عقار مميز في موقع حيوي، مساحة كبيرة ومواصفات عالية الجودة. يتميز بموقع استراتيجي في {districts[i % len(districts)]}، مع تشطيبات فاخرة وخدمات متكاملة.',
                'property_type': property_type,
                'rooms': 3 + (i % 4) if property_type not in ['أراضي'] else None,
                'bathrooms': 2 + (i % 3) if property_type not in ['أراضي'] else None,
                'area': 200 + (property_id * 50),
                'city': 'الطائف',
                'district': districts[i % len(districts)],
                'is_featured': property_id % 5 == 0,
                'status': statuses[i % len(statuses)],
                'mainImage': f'{real_estate_images[property_id % len(real_estate_images)]}?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
                'user': {
                    'phone': '966535342404',  # رقم الواتساب الرئيسي
                    'name': f'وسيط {property_id}'
                }
            })

    return properties

@main_bp.route('/')
def index():
    try:
        # Try to get real properties from database
        properties = Property.query.order_by(Property.created_at.desc()).all()
        current_app.logger.info("Successfully retrieved properties from database")
    except Exception as e:
        # If database error occurs, use dummy data
        current_app.logger.warning(f"Using dummy data due to database error: {str(e)}")
        properties = get_dummy_properties()

    return render_template('index.html', properties=properties)

@main_bp.route('/dashboard')
@login_required
def dashboard():
    try:
        if current_user.role != 'admin':
            return render_template('dashboard.html', error="غير مصرح لك بالوصول")

        properties = Property.query.join(User).all()
        return render_template('dashboard.html', properties=properties)
    except Exception as e:
        current_app.logger.error(f"Error in dashboard route: {str(e)}")
        return render_template('dashboard.html', properties=get_dummy_properties())

@main_bp.route('/profile/<username>')
def user_profile(username):
    try:
        user = User.query.filter_by(username=username).first_or_404()
        if user != current_user:
            user.increment_views()
        properties = Property.query.filter_by(user_id=user.id).all()
        return render_template('profile.html', user=user, properties=properties)
    except Exception as e:
        current_app.logger.error(f"Error in user_profile route: {str(e)}")
        return render_template('profile.html', 
                             user={'username': username, 'role': 'user'},
                             properties=get_dummy_properties()[:3])