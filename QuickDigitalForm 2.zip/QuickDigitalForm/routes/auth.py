from flask import Blueprint, request, jsonify, current_app
from flask_login import login_user, logout_user, login_required
from werkzeug.security import generate_password_hash, check_password_hash
from models import User
from extensions import db

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/login', methods=['POST'])
def login():
    try:
        username = request.form.get('username')
        password = request.form.get('password')

        if not username or not password:
            return jsonify({
                "status": "error",
                "message": "يرجى إدخال اسم المستخدم وكلمة المرور"
            }), 400

        user = User.query.filter_by(username=username).first()

        if user and user.check_password(password):
            login_user(user)
            return jsonify({
                "status": "success",
                "message": "تم تسجيل الدخول بنجاح",
                "user": {
                    "id": user.id,
                    "username": user.username,
                    "role": user.role,
                    "phone": user.phone
                }
            })

        return jsonify({
            "status": "error",
            "message": "اسم المستخدم أو كلمة المرور غير صحيحة"
        }), 401

    except Exception as e:
        current_app.logger.error(f"Login error: {str(e)}")
        return jsonify({
            "status": "error",
            "message": "حدث خطأ في النظام"
        }), 500

@auth_bp.route('/register', methods=['POST'])
def register():
    try:
        username = request.form.get('username')
        password = request.form.get('password')
        phone = request.form.get('phone')

        if not username or not password or not phone:
            return jsonify({
                "status": "error",
                "message": "يرجى إدخال جميع البيانات المطلوبة"
            }), 400

        if User.query.filter_by(username=username).first():
            return jsonify({
                "status": "error",
                "message": "اسم المستخدم مستخدم بالفعل"
            }), 400

        if User.query.filter_by(phone=phone).first():
            return jsonify({
                "status": "error",
                "message": "رقم الهاتف مستخدم بالفعل"
            }), 400

        user = User(
            username=username,
            phone=phone,
            password=password,
            role='agent'
        )

        db.session.add(user)
        db.session.commit()

        return jsonify({
            "status": "success",
            "message": "تم التسجيل بنجاح"
        })

    except Exception as e:
        current_app.logger.error(f"Registration error: {str(e)}")
        db.session.rollback()
        return jsonify({
            "status": "error",
            "message": "حدث خطأ في النظام"
        }), 500

@auth_bp.route('/logout')
@login_required
def logout():
    try:
        logout_user()
        return jsonify({
            "status": "success",
            "message": "تم تسجيل الخروج بنجاح"
        })
    except Exception as e:
        current_app.logger.error(f"Logout error: {str(e)}")
        return jsonify({
            "status": "error",
            "message": "حدث خطأ في تسجيل الخروج"
        }), 500